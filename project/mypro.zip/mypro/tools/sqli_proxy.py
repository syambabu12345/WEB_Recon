#!/usr/bin/env python3
import argparse
import requests
import urllib.parse

# Function to simulate SQL Injection attempt
def sqli_attack(url, param, payload, method="GET", proxies=None, output_file=None):
    # URL encode the payload
    payload_encoded = urllib.parse.quote(payload)
    full_url = f"{url}&{param}={payload_encoded}" if '?' in url else f"{url}?{param}={payload_encoded}"
    
    try:
        if method.upper() == "POST":
            data = {param: payload}
            response = requests.post(url, data=data, proxies=proxies)
        else:
            response = requests.get(full_url, proxies=proxies)
        
        # Check for common error messages or HTTP status codes
        if response.status_code == 500 or "error" in response.text.lower() or "syntax" in response.text.lower():
            result = f"[+] Potential SQL Injection vulnerability detected at {full_url}"
        else:
            result = f"[-] No vulnerability detected for payload: {payload}"
        
        # Print the result to the console
        print(result)
        
        # If output file is specified, log the result to that file
        if output_file:
            with open(output_file, "a") as log_file:
                log_file.write(result + "\n")
    
    except requests.exceptions.RequestException as e:
        print(f"[!] Error occurred: {e}")

# Function to extract query parameters from the URL
def extract_params(url):
    parsed_url = urllib.parse.urlparse(url)
    query_params = urllib.parse.parse_qs(parsed_url.query)
    
    # If no query parameters found, return an empty dictionary
    return query_params

# Function to parse command-line arguments and execute the tests
def main():
    # Set up the argument parser
    parser = argparse.ArgumentParser(description="Test for SQL Injection vulnerabilities on a website.")
    parser.add_argument("-u", "--url", required=True, help="Target URL to test (e.g., http://example.com/page?id=1&search=test)")
    parser.add_argument("-l", "--payloads", default="payloads.txt", help="File with SQL injection payloads (default: payloads.txt)")
    parser.add_argument("-m", "--method", choices=['GET', 'POST'], default="GET", help="Request method to use (default: GET)")
    parser.add_argument("-p", "--proxy", help="Proxy to use for requests (e.g., http://127.0.0.1:8080)")
    parser.add_argument("-o", "--output", help="Output file to save results (default: None, prints to console)")
    
    args = parser.parse_args()

    # Read the SQL injection payloads from the specified file
    try:
        with open(args.payloads, 'r') as f:
            payloads = [line.strip() for line in f.readlines()]
    except FileNotFoundError:
        print(f"[!] Payload file '{args.payloads}' not found.")
        exit(1)

    # Extract query parameters from the URL
    query_params = extract_params(args.url)

    # If there are no query parameters, exit
    if not query_params:
        print(f"[!] No query parameters found in URL {args.url}")
        exit(1)

    # Set up proxies if specified
    proxies = None
    if args.proxy:
        proxies = {
            'http': args.proxy,
            'https': args.proxy
        }

    # Test each parameter on the target URL with each payload
    for param in query_params:
        for payload in payloads:
            print(f"Testing parameter: {param} with payload: {payload}")
            sqli_attack(args.url, param, payload, method=args.method, proxies=proxies, output_file=args.output)

    print(f"[*] SQL Injection Test Completed. Check the output for results.")
main()


