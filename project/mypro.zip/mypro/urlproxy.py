import requests
from bs4 import BeautifulSoup
import re
import argparse

def extract_urls_from_script(script_content):
    """Extract URLs embedded in JavaScript."""
    urls = []
    # Regular expression to find URLs in JavaScript (http, https, or other schemes)
    url_pattern = re.compile(r'(https?://[^\s"<>]+)')
    urls.extend(url_pattern.findall(script_content))
    return urls

def extract_urls_from_styles(styles_content):
    """Extract URLs from CSS styles (e.g., background images)."""
    urls = []
    # Regular expression to find URLs in CSS (background-image, etc.)
    url_pattern = re.compile(r'url\((https?://[^\s"<>]+)\)')
    urls.extend(url_pattern.findall(styles_content))
    return urls

def extract_links_from_html(soup):
    """Extract all links from the HTML."""
    links = []

    # Find all <a> tags (links) in the HTML
    for link in soup.find_all('a'):
        href = link.get('href')
        if href:
            links.append(href)

    # Extract links from other attributes
    for tag in soup.find_all(True):  # loop through all tags
        for attr in ['src', 'data-src', 'action', 'formaction']:
            url = tag.get(attr)
            if url:
                links.append(url)

    return links

def scrape_links(url, proxies=None):
    """Scrape and print all found links (including hidden URLs)."""
    try:
        # Send GET request to the URL with optional proxy
        response = requests.get(url, proxies=proxies)
        
        # Check for a successful response
        if response.status_code != 200:
            print(f"Failed to retrieve {url} (status code {response.status_code})")
            return
        
        # Parse the response text with BeautifulSoup
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract links from the HTML content (anchor links, src, data-src, etc.)
        links = extract_links_from_html(soup)

        # Print all found links (anchor links, JavaScript, CSS, other attributes)
        for link in links:
            if link.startswith('http://') or link.startswith('https://'):
                print(f"Found link: {link}")

        # Look for JavaScript embedded URLs (onclick, JavaScript URL patterns)
        scripts = soup.find_all('script')
        for script in scripts:
            if script.string:  # If there's script content
                script_urls = extract_urls_from_script(script.string)
                for script_url in script_urls:
                    print(f"Found JavaScript link: {script_url}")

        # Look for URLs in CSS (e.g., background images)
        styles = soup.find_all('style')
        for style in styles:
            if style.string:  # If there's style content
                style_urls = extract_urls_from_styles(style.string)
                for style_url in style_urls:
                    print(f"Found CSS background URL: {style_url}")

    except Exception as e:
        print(f"An error occurred while processing {url}: {e}")

def process_file(file_path, proxies=None):
    """Process each URL from the file."""
    try:
        # Open and read the file containing URLs
        with open(file_path, 'r') as file:
            urls = file.readlines()
        
        # Iterate over each URL and scrape links
        for url in urls:
            url = url.strip()  # Remove leading/trailing whitespaces or newlines
            if url:  # Skip empty lines
                print(f"Processing URL: {url}")
                scrape_links(url, proxies)
                
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")

# Set up argparse to handle the file input and proxy settings via command line arguments
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Scrape all links, including hidden URLs, from webpages in a file")
    
    # Add the file argument (the file containing URLs)
    parser.add_argument("file", help="Path to the file containing URLs", type=str)
    
    # Add proxy argument (IP:Port for proxy)
    parser.add_argument("--proxy", help="Proxy IP and Port (e.g., http://192.168.1.100:8080)", type=str, default=None)
    
    # Parse the command-line arguments
    args = parser.parse_args()
    
    # Set up the proxies dictionary if provided
    proxies = None
    if args.proxy:
        # Assuming the proxy format is http://ip:port
        proxies = {
            "http": args.proxy,
            "https": args.proxy
        }

    # Call the function to process the file and scrape the links
    process_file(args.file, proxies)
