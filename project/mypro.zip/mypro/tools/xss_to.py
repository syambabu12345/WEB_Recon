from pyflyght import CLI, Option, Argument
import requests
from urllib.parse import urlencode
import time

def test_xss(url: str, payload_file: str, proxy: str):
    """
    Test for XSS vulnerabilities using a list of payloads.
    """
    headers = {"User-Agent": "XSS-Tester/1.0"}
    proxy_dict = {"http": proxy, "https": proxy} if proxy else None

    try:
        # Load payloads from the file
        with open(payload_file, "r") as file:
            payloads = [line.strip() for line in file if line.strip()]

        print(f"Testing URL: {url} with {len(payloads)} payloads...")

        vulnerable = False
        for payload in payloads:
            payload_encoded = urlencode({"input": payload})  # Replace "input" with actual parameter name
            test_url = f"{url}?{payload_encoded}"

            try:
                print(f"Testing payload: {payload}")
                response = requests.get(test_url, headers=headers, proxies=proxy_dict, timeout=10)

                if payload in response.text:
                    print(f"[+] Vulnerable to XSS! Payload: {payload}")
                    vulnerable = True
            except requests.RequestException as e:
                print(f"[-] Error testing payload {payload}: {e}")

        if not vulnerable:
            print("[-] No vulnerabilities found.")

    except FileNotFoundError:
        print(f"[-] Payload file not found: {payload_file}")


# Create the CLI application
cli = CLI("XSS Tester", description="A CLI tool for detecting XSS vulnerabilities.")

# Add options and arguments
cli.add_option(Option("--proxy", type=str, default=None, help="Optional proxy (e.g., http://127.0.0.1:8080)."))
cli.add_argument(Argument("url", type=str, help="The target URL to test."))
cli.add_argument(Argument("payload_file", type=str, help="Path to the file containing XSS payloads."))

# Bind the function to the CLI
cli.bind(test_xss)

if __name__ == "__main__":
    cli.run()
