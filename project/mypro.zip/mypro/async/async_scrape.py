import re
import aiohttp
import asyncio
import aiofiles
from bs4 import BeautifulSoup

async def extract_urls_from_script(script_content):
    """Extract URLs embedded in JavaScript."""
    urls = []
    # Regular expression to find URLs in JavaScript (http, https, or other schemes)
    url_pattern = re.compile(r'(https?://[^\s"<>]+)')
    urls.extend(url_pattern.findall(script_content))
    return urls

async def extract_urls_from_styles(styles_content):
    """Extract URLs from CSS styles (e.g., background images)."""
    urls = []
    # Regular expression to find URLs in CSS (background-image, etc.)
    url_pattern = re.compile(r'url\((https?://[^\s"<>]+)\)')
    urls.extend(url_pattern.findall(styles_content))
    return urls

async def extract_links_from_html(soup):
    """Extract all links from the HTML."""
    links = []

    # Find all <a> tags (links) in the HTML
    for link in soup.find_all('a'):
        href = link.get('href')
        if href:
            links.append(href)

    # Extract links from other attributes
    for tag in soup.find_all(True):  # loop through all tags
        for attr in ['src', 'data-src', 'action', 'formaction']:
            url = tag.get(attr)
            if url:
                links.append(url)

    return links

async def scrape_links(session, url):
    """Scrape and print all found links (including hidden URLs)."""
    try:
        # Send GET request to the URL asynchronously
        async with session.get(url) as response:
            if response.status != 200:
                print(f"Failed to retrieve {url} (status code {response.status})")
                return

            # Parse the response text with BeautifulSoup
            html_content = await response.text()
            soup = BeautifulSoup(html_content, 'html.parser')

            # Extract links from the HTML content (anchor links, src, data-src, etc.)
            links = await extract_links_from_html(soup)

            # Print all found links (anchor links, JavaScript, CSS, other attributes)
            for link in links:
                if link.startswith('http://') or link.startswith('https://'):
                    print(f"Found link: {link}")

            # Look for JavaScript embedded URLs (onclick, JavaScript URL patterns)
            scripts = soup.find_all('script')
            for script in scripts:
                if script.string:  # If there's script content
                    script_urls = await extract_urls_from_script(script.string)
                    for script_url in script_urls:
                        print(f"Found JavaScript link: {script_url}")

            # Look for URLs in CSS (e.g., background images)
            styles = soup.find_all('style')
            for style in styles:
                if style.string:  # If there's style content
                    style_urls = await extract_urls_from_styles(style.string)
                    for style_url in style_urls:
                        print(f"Found CSS background URL: {style_url}")

    except Exception as e:
        print(f"An error occurred while processing {url}: {e}")

async def process_file(file_path):
    """Process each URL from the file asynchronously."""
    try:
        # Open and read the file containing URLs asynchronously
        async with aiofiles.open(file_path, 'r') as file:
            urls = await file.readlines()

        # Create an aiohttp session for HTTP requests
        async with aiohttp.ClientSession() as session:
            # Iterate over each URL and scrape links asynchronously
            tasks = []
            for url in urls:
                url = url.strip()  # Remove leading/trailing whitespaces or newlines
                if url:  # Skip empty lines
                    print(f"Processing URL: {url}")
                    task = scrape_links(session, url)
                    tasks.append(task)

            # Wait for all the tasks to finish
            await asyncio.gather(*tasks)

    except Exception as e:
        print(f"An error occurred while reading the file: {e}")

# Set up argparse to handle the file input via command line arguments
def main():
    import argparse

    parser = argparse.ArgumentParser(description="Scrape all links, including hidden URLs, from webpages in a file")
    
    # Add the file argument (the file containing URLs)
    parser.add_argument("file", help="Path to the file containing URLs", type=str)
    
    # Parse the command-line arguments
    args = parser.parse_args()
    
    # Call the function to process the file and scrape the links asynchronously
    asyncio.run(process_file(args.file))

if __name__ == "__main__":
    main()
